extends Node

signal state_changed
signal tick
signal event_changed
signal toast_requested(message)

const D = preload("res://scripts/FFData.gd")
const SAVE_PATH := "user://first_fire_alpha01.json"
const DAY_SECONDS := 240.0

var rng := RandomNumberGenerator.new()
var sim_paused := false
var initialized := false
var save_existed_on_boot := false
var ui_emit_accum := 0.0
var autosave_accum := 0.0
var camp_event_accum := 0.0
var camp_event_cooldown := 0.0

var day := 1
var day_elapsed := 0.0
var resources := {}
var components := {}
var inventory_gear := []
var buildings := {}
var survivors := []
var next_survivor_id := 1
var next_expedition_id := 1
var expeditions := []
var zone_successes := {}
var zone_pressure := {}
var unlocked_zones := []
var special_sites := {}
var history := []
var flags := {}
var policies := {}
var current_event := {}
var event_queue := []
var coordinator_id := -1
var leader_id := -1
var leadership_form := "None"
var eligible_expeditions_since_recruit := 0
var food_shortage_days := 0
var water_shortage_days := 0
var garden_tended_day := -1
var game_over := false
var alpha_complete := false
var alpha_complete_shown := false
var recent_expedition_ids := []

func _ready():
    rng.randomize()
    save_existed_on_boot = FileAccess.file_exists(SAVE_PATH)
    if save_existed_on_boot:
        load_game()
    else:
        new_game()
    initialized = true
    set_process(true)

func has_save_game():
    return FileAccess.file_exists(SAVE_PATH)

func new_game():
    day = 1
    day_elapsed = 0.0
    resources = D.STARTING_RESOURCES.duplicate(true)
    components = {"Sterile Dressing": 0, "Framing Kit": 0, "Pack Frame": 0, "Weatherproofing Roll": 0}
    inventory_gear = []
    buildings = {"Fire Pit": true, "Sleeping Bag": true}
    for b in D.BUILD_ORDER:
        buildings[b] = false
    survivors = []
    next_survivor_id = 1
    next_expedition_id = 1
    expeditions = []
    zone_successes = {}
    zone_pressure = {}
    for z in D.ZONE_ORDER:
        zone_successes[z] = 0
        zone_pressure[z] = 0
    unlocked_zones = ["Camp Perimeter"]
    special_sites = {}
    for site in D.SPECIAL_SITES.keys():
        special_sites[site] = {"discovered": false, "cleared": false}
    history = []
    flags = {}
    policies = {}
    current_event = {}
    event_queue = []
    coordinator_id = -1
    leader_id = -1
    leadership_form = "None"
    eligible_expeditions_since_recruit = 0
    food_shortage_days = 0
    water_shortage_days = 0
    garden_tended_day = -1
    game_over = false
    alpha_complete = false
    alpha_complete_shown = false
    recent_expedition_ids = []
    camp_event_accum = 0.0
    camp_event_cooldown = 20.0
    sim_paused = false
    var founder = _generate_survivor(true)
    founder["equipment"] = {"Weapon": "Utility Knife", "Clothing": "", "Pack": "Worn Backpack", "Tool": ""}
    founder["history"].append("Day 1 — Established First Fire.")
    survivors.append(founder)
    _add_history("Day 1 — %s established First Fire." % founder["name"])
    save_game()
    state_changed.emit()

func _process(delta):
    if not initialized or sim_paused or game_over:
        return
    day_elapsed += delta
    ui_emit_accum += delta
    autosave_accum += delta
    camp_event_accum += delta
    if camp_event_cooldown > 0.0:
        camp_event_cooldown = max(0.0, camp_event_cooldown - delta)

    _process_survivors(delta)
    _process_expeditions(delta)

    if day_elapsed >= DAY_SECONDS:
        while day_elapsed >= DAY_SECONDS:
            day_elapsed -= DAY_SECONDS
            _daily_tick()

    if camp_event_accum >= 45.0:
        camp_event_accum -= 45.0
        _consider_camp_event()

    _consider_politics()
    _check_alpha_complete()

    if autosave_accum >= 10.0:
        autosave_accum = 0.0
        save_game()

    if ui_emit_accum >= 0.25:
        ui_emit_accum = 0.0
        tick.emit()

func _notification(what):
    if not initialized:
        return
    if what == MainLoop.NOTIFICATION_APPLICATION_PAUSED or what == MainLoop.NOTIFICATION_APPLICATION_FOCUS_OUT:
        sim_paused = true
        save_game()
        state_changed.emit()
    elif what == MainLoop.NOTIFICATION_APPLICATION_RESUMED or what == MainLoop.NOTIFICATION_APPLICATION_FOCUS_IN:
        # Deliberately remain paused after returning. The player resumes explicitly.
        state_changed.emit()

func toggle_pause():
    sim_paused = not sim_paused
    save_game()
    state_changed.emit()

func set_paused(value):
    sim_paused = value
    save_game()
    state_changed.emit()

func formatted_time():
    var minutes_into_day = int((day_elapsed / DAY_SECONDS) * 1440.0)
    var total_minutes = (8 * 60 + minutes_into_day) % 1440
    var hour = total_minutes / 60
    var minute = total_minutes % 60
    var suffix = "AM"
    var display_hour = hour
    if hour >= 12:
        suffix = "PM"
    if display_hour == 0:
        display_hour = 12
    elif display_hour > 12:
        display_hour -= 12
    return "%d:%02d %s" % [display_hour, minute, suffix]

func shelter_capacity():
    if buildings.get("Cabin", false):
        return 5
    if buildings.get("Makeshift Shelter", false):
        return 3
    return 1

func population():
    var count = 0
    for s in survivors:
        if s["condition"] != "Dead":
            count += 1
    return count

func available_survivors():
    var result = []
    for s in survivors:
        if s["condition"] != "Dead" and s["status"] == "Available":
            result.append(s)
    return result

func get_survivor(id) -> Variant:
    for s in survivors:
        if int(s["id"]) == int(id):
            return s
    return null

func _generate_survivor(founder = false, preferred_background = ""):
    var s = {
        "id": next_survivor_id,
        "name": "",
        "background": "",
        "skills": {"Combat": 0, "Scavenging": 0, "Survival": 0, "Medical": 0, "Technical": 0, "Social": 0},
        "skill_xp": {"Combat": 0, "Scavenging": 0, "Survival": 0, "Medical": 0, "Technical": 0, "Social": 0},
        "traits": [],
        "fatigue": 0.0,
        "stress": 10.0 if not founder else 5.0,
        "condition": "Healthy",
        "injury_remaining": 0.0,
        "status": "Available",
        "task": {},
        "equipment": {"Weapon": "", "Clothing": "", "Pack": "", "Tool": ""},
        "relationships": {},
        "reputation": 0,
        "leader_support": 0,
        "leader_ability": "",
        "history": [],
        "expeditions_done": 0,
    }
    next_survivor_id += 1
    s["name"] = "%s %s" % [D.FIRST_NAMES[rng.randi_range(0, D.FIRST_NAMES.size() - 1)], D.LAST_NAMES[rng.randi_range(0, D.LAST_NAMES.size() - 1)]]
    var background_names = D.BACKGROUNDS.keys()
    if preferred_background != "" and D.BACKGROUNDS.has(preferred_background):
        s["background"] = preferred_background
    else:
        s["background"] = background_names[rng.randi_range(0, background_names.size() - 1)]

    for skill in s["skills"].keys():
        s["skills"][skill] = rng.randi_range(1, 3) if founder else rng.randi_range(0, 3)
    for skill in D.BACKGROUNDS[s["background"]].keys():
        s["skills"][skill] = min(5, int(s["skills"][skill]) + int(D.BACKGROUNDS[s["background"]][skill]))

    if s["background"] == "College Student":
        var random_skills = s["skills"].keys()
        var chosen = random_skills[rng.randi_range(0, random_skills.size() - 1)]
        s["skills"][chosen] = min(5, int(s["skills"][chosen]) + 2)
    elif s["background"] == "Retiree":
        var random_skills2 = s["skills"].keys()
        var chosen2 = random_skills2[rng.randi_range(0, random_skills2.size() - 1)]
        s["skills"][chosen2] = min(5, int(s["skills"][chosen2]) + 2)

    if founder:
        for skill in s["skills"].keys():
            s["skills"][skill] = clamp(int(s["skills"][skill]), 1, 4)

    var t1 = D.TRAITS[rng.randi_range(0, D.TRAITS.size() - 1)]
    var t2 = D.TRAITS[rng.randi_range(0, D.TRAITS.size() - 1)]
    var attempts = 0
    while (t2 == t1 or D.INCOMPATIBLE_TRAITS.get(t1, []).has(t2)) and attempts < 30:
        t2 = D.TRAITS[rng.randi_range(0, D.TRAITS.size() - 1)]
        attempts += 1
    s["traits"] = [t1, t2]
    s["leader_ability"] = _derive_leader_ability(s)
    return s

func _derive_leader_ability(s):
    var skills = s["skills"]
    if int(skills["Technical"]) >= 4:
        return "Organizer"
    if int(skills["Scavenging"]) >= 4 or int(skills["Survival"]) >= 4:
        return "Provider"
    if int(skills["Medical"]) >= 4:
        return "Caretaker"
    if int(skills["Social"]) >= 4 or s["traits"].has("Diplomatic"):
        return "Mediator"
    if s["traits"].has("Suspicious") or s["traits"].has("Cautious"):
        return "Watchful"
    return "Pragmatist"

func _initialize_relationships(new_survivor):
    for other in survivors:
        if other["condition"] == "Dead" or int(other["id"]) == int(new_survivor["id"]):
            continue
        var a = rng.randi_range(0, 10)
        var b = rng.randi_range(0, 10)
        new_survivor["relationships"][str(other["id"])] = a
        other["relationships"][str(new_survivor["id"])] = b

func _add_recruit(preferred_background = "", rescuer_ids = []) -> Variant:
    if population() >= shelter_capacity() + 1:
        toast_requested.emit("There is no room for another survivor right now.")
        return null
    var s = _generate_survivor(false, preferred_background)
    _initialize_relationships(s)
    if rng.randf() < 0.45:
        s["equipment"]["Pack"] = "Worn Backpack"
    for rid in rescuer_ids:
        s["relationships"][str(rid)] = rng.randi_range(15, 25)
        var rescuer: Variant = get_survivor(rid)
        if rescuer != null:
            rescuer["relationships"][str(s["id"])] = rng.randi_range(5, 15)
            _change_reputation(rescuer, 5)
    survivors.append(s)
    s["history"].append("Day %d — Joined First Fire." % day)
    _add_history("Day %d — %s joined First Fire." % [day, s["name"]])
    eligible_expeditions_since_recruit = 0
    save_game()
    state_changed.emit()
    return s

func relationship_label(value):
    value = int(value)
    if value >= 60: return "Close"
    if value >= 25: return "Friendly"
    if value <= -60: return "Hostile"
    if value <= -25: return "Tense"
    return "Neutral"

func _change_relationship(a, b, amount):
    if a == null or b == null:
        return
    var key = str(b["id"])
    var adjusted = float(amount)
    if amount > 0 and a["traits"].has("Friendly"):
        adjusted *= 1.25
    if amount > 0 and a["traits"].has("Loner"):
        adjusted *= 0.5
    if amount < 0 and leader_id == int(a["id"]) and a["leader_ability"] == "Mediator":
        adjusted *= 0.75
    a["relationships"][key] = clamp(int(a["relationships"].get(key, 0)) + int(round(adjusted)), -100, 100)

func _change_reputation(s, amount):
    s["reputation"] = int(s.get("reputation", 0)) + int(amount)

func add_skill_xp(s, skill, amount):
    if s == null or not s["skills"].has(skill):
        return
    s["skill_xp"][skill] = int(s["skill_xp"].get(skill, 0)) + int(amount)
    var rank = int(s["skills"][skill])
    var threshold = 20 + rank * 15
    while rank < 10 and int(s["skill_xp"][skill]) >= threshold:
        s["skill_xp"][skill] = int(s["skill_xp"][skill]) - threshold
        rank += 1
        s["skills"][skill] = rank
        s["history"].append("Day %d — Reached %s %d." % [day, skill, rank])
        _add_history("Day %d — %s reached %s %d." % [day, s["name"], skill, rank])
        threshold = 20 + rank * 15

func skill_check(s, skill, dc, extra = 0):
    var effective = int(s["skills"].get(skill, 0)) + int(extra)
    if s["fatigue"] >= 80 and ["Combat", "Scavenging", "Survival", "Technical"].has(skill):
        effective -= 2
    elif s["fatigue"] >= 60 and ["Combat", "Scavenging", "Survival", "Technical"].has(skill):
        effective -= 1
    if s["traits"].has("Nervous") and s["stress"] >= 50 and ["Combat", "Survival"].has(skill):
        effective -= 1
    if s["traits"].has("Calm") and skill == "Survival":
        effective += 1
    if s["traits"].has("Diplomatic") and skill == "Social":
        effective += 1
    var roll = rng.randi_range(1, 10) + effective
    if roll >= dc + 4: return 2
    if roll >= dc: return 1
    if roll >= dc - 2: return 0
    return -1

func _process_survivors(delta):
    for s in survivors:
        if s["condition"] == "Dead":
            continue
        if s["status"] == "Resting":
            var fatigue_rate = 0.5 if buildings.get("Cabin", false) else (1.0 / 3.0)
            var stress_rate = (1.0 / 6.0) if buildings.get("Cabin", false) else 0.1
            if leader_id != -1:
                var leader: Variant = get_survivor(leader_id)
                if leader != null and leader["leader_ability"] == "Caretaker":
                    fatigue_rate *= 1.2
                    stress_rate *= 1.2
            s["fatigue"] = max(0.0, float(s["fatigue"]) - fatigue_rate * delta)
            s["stress"] = max(0.0, float(s["stress"]) - stress_rate * delta)
            if s["condition"] == "Hurt" or s["condition"] == "Wounded":
                s["injury_remaining"] = max(0.0, float(s["injury_remaining"]) - delta)
                if s["injury_remaining"] <= 0.0:
                    if s["condition"] == "Wounded":
                        s["condition"] = "Hurt"
                        s["injury_remaining"] = 60.0
                        s["history"].append("Day %d — Recovered from a serious wound." % day)
                    else:
                        s["condition"] = "Healthy"
                        s["history"].append("Day %d — Recovered from minor injuries." % day)
        elif ["Crafting", "Building", "Recovering", "Tending"].has(s["status"]):
            if s["task"].is_empty():
                s["status"] = "Available"
                continue
            s["task"]["remaining"] = max(0.0, float(s["task"]["remaining"]) - delta)
            if float(s["task"]["remaining"]) <= 0.0:
                _complete_task(s)

func set_resting(sid, value):
    var s: Variant = get_survivor(sid)
    if s == null or s["condition"] == "Dead":
        return
    if value and s["status"] == "Available":
        s["status"] = "Resting"
    elif not value and s["status"] == "Resting":
        s["status"] = "Available"
    save_game()
    state_changed.emit()

func treat_survivor(sid):
    var s: Variant = get_survivor(sid)
    if s == null or s["condition"] == "Healthy" or s["condition"] == "Dead":
        return false
    if s["status"] != "Available" and s["status"] != "Resting":
        return false
    if s["condition"] == "Hurt":
        if int(components.get("Sterile Dressing", 0)) <= 0:
            toast_requested.emit("You need a Sterile Dressing.")
            return false
        components["Sterile Dressing"] -= 1
        s["injury_remaining"] = min(float(s["injury_remaining"]), 30.0)
        s["status"] = "Resting"
    else:
        if int(resources.get("Medicine", 0)) <= 0:
            toast_requested.emit("You need Medicine.")
            return false
        resources["Medicine"] -= 1
        s["status"] = "Recovering"
        var base = 45.0 if s["condition"] == "Wounded" else 120.0
        var medical_skill = _best_available_skill("Medical", sid)
        var reduction = min(0.35, medical_skill * 0.04)
        s["task"] = {"kind": "treatment", "remaining": base * (1.0 - reduction), "duration": base, "target": sid}
    save_game()
    state_changed.emit()
    return true

func _best_available_skill(skill, exclude_id = -1):
    var best = 0
    for s in survivors:
        if int(s["id"]) == int(exclude_id) or s["condition"] == "Dead":
            continue
        if s["status"] == "Available" or s["status"] == "Resting":
            best = max(best, int(s["skills"].get(skill, 0)))
    return best

func _complete_task(s):
    var task = s["task"].duplicate(true)
    s["task"] = {}
    s["status"] = "Available"
    var kind = task.get("kind", "")
    if kind == "craft":
        var recipe = task["recipe"]
        if recipe.has("gives_resource"):
            for key in recipe["gives_resource"].keys():
                resources[key] = int(resources.get(key, 0)) + int(recipe["gives_resource"][key])
        if recipe.has("gives_component"):
            for key in recipe["gives_component"].keys():
                components[key] = int(components.get(key, 0)) + int(recipe["gives_component"][key])
        if recipe.has("gives_gear"):
            inventory_gear.append(recipe["gives_gear"])
        add_skill_xp(s, "Technical", clamp(int(float(task["duration"]) / 3.0), 2, 12))
        _add_history("Day %d — %s crafted %s." % [day, s["name"], recipe["id"]])
        toast_requested.emit("%s finished %s." % [s["name"], recipe["id"]])
    elif kind == "build":
        var building = task["building"]
        buildings[building] = true
        add_skill_xp(s, "Technical", clamp(int(float(task["duration"]) / 3.0), 2, 12))
        _change_reputation(s, 2)
        s["history"].append("Day %d — Helped complete %s." % [day, building])
        _add_history("Day %d — %s completed %s." % [day, s["name"], building])
        toast_requested.emit("%s completed." % building)
    elif kind == "garden":
        garden_tended_day = day
        add_skill_xp(s, "Technical", 2)
        toast_requested.emit("Garden tended for Day %d." % day)
    elif kind == "treatment":
        if s["condition"] == "Critical":
            s["condition"] = "Wounded"
            s["injury_remaining"] = 180.0
        elif s["condition"] == "Wounded":
            s["condition"] = "Hurt"
            s["injury_remaining"] = 60.0
        s["status"] = "Resting"
        toast_requested.emit("%s's treatment is complete." % s["name"])
    save_game()
    state_changed.emit()

func _can_pay(cost, component_cost = {}):
    for key in cost.keys():
        if int(resources.get(key, 0)) < int(cost[key]):
            return false
    for key in component_cost.keys():
        if int(components.get(key, 0)) < int(component_cost[key]):
            return false
    return true

func _pay(cost, component_cost = {}):
    for key in cost.keys():
        resources[key] = int(resources.get(key, 0)) - int(cost[key])
    for key in component_cost.keys():
        components[key] = int(components.get(key, 0)) - int(component_cost[key])

func start_craft(sid, station, recipe_id):
    var s: Variant = get_survivor(sid)
    if s == null or s["status"] != "Available":
        return false
    if station != "Fire Pit" and not buildings.get(station, false):
        return false
    var recipe: Variant = null
    for r in D.RECIPES.get(station, []):
        if r["id"] == recipe_id:
            recipe = r
            break
    if recipe == null:
        return false
    var cc = recipe.get("component_cost", {})
    if not _can_pay(recipe.get("cost", {}), cc):
        toast_requested.emit("Not enough materials.")
        return false
    _pay(recipe.get("cost", {}), cc)
    var duration = _work_duration(s, float(recipe["time"]))
    s["status"] = "Crafting"
    s["fatigue"] = min(100.0, float(s["fatigue"]) + float(recipe["time"]) / 5.0)
    s["task"] = {"kind": "craft", "station": station, "recipe": recipe.duplicate(true), "remaining": duration, "duration": float(recipe["time"])}
    save_game()
    state_changed.emit()
    return true

func start_build(sid, building):
    var s: Variant = get_survivor(sid)
    if s == null or s["status"] != "Available":
        return false
    if buildings.get(building, false) or not D.BUILDINGS.has(building):
        return false
    var data = D.BUILDINGS[building]
    for req in data.get("requires", []):
        if not buildings.get(req, false):
            toast_requested.emit("Requires %s." % req)
            return false
    if not _can_pay(data.get("cost", {}), data.get("component_cost", {})):
        toast_requested.emit("Not enough materials/components.")
        return false
    _pay(data.get("cost", {}), data.get("component_cost", {}))
    var duration = _work_duration(s, float(data["time"]))
    s["status"] = "Building"
    s["fatigue"] = min(100.0, float(s["fatigue"]) + float(data["time"]) / 5.0)
    s["task"] = {"kind": "build", "building": building, "remaining": duration, "duration": float(data["time"])}
    save_game()
    state_changed.emit()
    return true

func tend_garden(sid):
    if not buildings.get("Garden Plot", false):
        return false
    if garden_tended_day == day:
        toast_requested.emit("The garden has already been tended today.")
        return false
    var s: Variant = get_survivor(sid)
    if s == null or s["status"] != "Available":
        return false
    s["status"] = "Tending"
    s["task"] = {"kind": "garden", "remaining": _work_duration(s, 8.0), "duration": 8.0}
    save_game()
    state_changed.emit()
    return true

func _work_duration(s, base):
    var reduction = min(0.30, int(s["skills"]["Technical"]) * 0.04)
    if s["traits"].has("Hard Worker"):
        reduction += 0.10
    elif s["traits"].has("Lazy"):
        reduction -= 0.10
    var leader: Variant = get_survivor(leader_id)
    if leader != null and leader["leader_ability"] == "Organizer":
        reduction += 0.10
    return max(base * 0.45, base * (1.0 - reduction))

func equip_gear(sid, gear_name):
    var s: Variant = get_survivor(sid)
    if s == null or not inventory_gear.has(gear_name) or not D.GEAR.has(gear_name):
        return false
    var slot = D.GEAR[gear_name]["slot"]
    var old = s["equipment"].get(slot, "")
    inventory_gear.erase(gear_name)
    if old != "":
        inventory_gear.append(old)
    s["equipment"][slot] = gear_name
    save_game()
    state_changed.emit()
    return true

func _process_expeditions(delta):
    var finished = []
    for exp in expeditions:
        if exp.get("state", "") != "traveling":
            continue
        exp["remaining"] = max(0.0, float(exp["remaining"]) - delta)
        if exp.get("event_key", "") != "" and not exp.get("event_triggered", false) and float(exp["remaining"]) <= float(exp["event_trigger_remaining"]):
            exp["event_triggered"] = true
            exp["state"] = "pending"
            for sid in exp["survivor_ids"]:
                var s: Variant = get_survivor(sid)
                if s != null:
                    s["status"] = "Pending Expedition Event"
            _queue_event(_build_field_event(exp["event_key"], exp))
        elif float(exp["remaining"]) <= 0.0:
            finished.append(exp["id"])
    for eid in finished:
        _finish_expedition(eid)

func start_expedition(primary_id, companion_id, zone, focus):
    if not unlocked_zones.has(zone) or not D.ZONES.has(zone):
        return false
    var party_ids = [int(primary_id)]
    if int(companion_id) > 0 and int(companion_id) != int(primary_id):
        party_ids.append(int(companion_id))
    for sid in party_ids:
        var s: Variant = get_survivor(sid)
        if s == null or s["status"] != "Available" or s["condition"] == "Dead":
            return false
        if zone in ["Commercial Fringe", "Industrial Edge"] and float(s["fatigue"]) >= 95.0:
            toast_requested.emit("%s is too exhausted for that trip." % s["name"])
            return false
        if zone in ["Commercial Fringe", "Industrial Edge"] and s["condition"] == "Wounded":
            toast_requested.emit("%s is too badly wounded for that trip." % s["name"])
            return false

    eligible_expeditions_since_recruit += 1
    var avg_survival = 0.0
    for sid in party_ids:
        avg_survival += int(get_survivor(sid)["skills"]["Survival"])
    avg_survival /= party_ids.size()
    var reduction = min(0.20, avg_survival * 0.025)
    var duration = float(D.ZONES[zone]["duration"]) * (1.0 - reduction)
    var force_recruit = false
    if population() == 1 and eligible_expeditions_since_recruit >= 5:
        force_recruit = true
    elif population() >= 2 and population() < 5 and eligible_expeditions_since_recruit >= 7:
        force_recruit = true
    if population() >= shelter_capacity() + 1:
        force_recruit = false

    var event_key = ""
    if force_recruit:
        event_key = "injured_stranger"
    elif rng.randf() < float(D.ZONES[zone]["event_chance"]):
        event_key = _select_field_event(zone)

    var exp = {
        "id": next_expedition_id,
        "survivor_ids": party_ids,
        "zone": zone,
        "focus": focus,
        "duration": duration,
        "remaining": duration,
        "state": "traveling",
        "event_key": event_key,
        "event_triggered": false,
        "event_trigger_remaining": duration * rng.randf_range(0.25, 0.65),
        "special_site": "",
    }
    next_expedition_id += 1
    expeditions.append(exp)
    for sid in party_ids:
        var s: Variant = get_survivor(sid)
        s["status"] = "Expedition"
        s["task"] = {"expedition_id": exp["id"]}
    recent_expedition_ids.append(primary_id)
    if recent_expedition_ids.size() > 4:
        recent_expedition_ids.pop_front()
    save_game()
    state_changed.emit()
    return true

func start_special_site(primary_id, companion_id, site):
    if not special_sites.has(site) or not special_sites[site]["discovered"] or special_sites[site]["cleared"]:
        return false
    var party_ids = [int(primary_id)]
    if int(companion_id) > 0 and int(companion_id) != int(primary_id):
        party_ids.append(int(companion_id))
    for sid in party_ids:
        var s: Variant = get_survivor(sid)
        if s == null or s["status"] != "Available":
            return false
    var duration = float(D.SPECIAL_SITES[site]["duration"])
    var exp = {
        "id": next_expedition_id, "survivor_ids": party_ids,
        "zone": D.SPECIAL_SITES[site]["zone"], "focus": "Special",
        "duration": duration, "remaining": duration, "state": "traveling",
        "event_key": "", "event_triggered": true, "event_trigger_remaining": -1.0,
        "special_site": site,
    }
    next_expedition_id += 1
    expeditions.append(exp)
    for sid in party_ids:
        var s: Variant = get_survivor(sid)
        s["status"] = "Expedition"
        s["task"] = {"expedition_id": exp["id"]}
    save_game()
    state_changed.emit()
    return true

func _select_field_event(zone):
    var pool = []
    if zone == "Camp Perimeter":
        pool = ["backpack"]
    elif zone == "Nearby Streets":
        pool = ["backpack", "injured_stranger", "dog"]
    elif zone == "Residential Blocks":
        pool = ["backpack", "someone_inside", "injured_stranger", "dog", "locked_garage", "gunshot", "smoke"]
    elif zone == "Commercial Fringe":
        pool = ["injured_stranger", "gunshot", "discover_market", "discover_clinic", "hardware_cage", "patrol_car", "smoke", "barricade"]
    elif zone == "Industrial Edge":
        pool = ["gunshot", "barricade", "construction_trailer", "locked_office", "smoke"]
    return pool[rng.randi_range(0, pool.size() - 1)] if not pool.is_empty() else ""

func _find_expedition(eid) -> Variant:
    for exp in expeditions:
        if int(exp["id"]) == int(eid):
            return exp
    return null

func _resume_expedition(eid):
    var exp: Variant = _find_expedition(eid)
    if exp == null:
        return
    exp["state"] = "traveling"
    for sid in exp["survivor_ids"]:
        var s: Variant = get_survivor(sid)
        if s != null and s["condition"] != "Dead":
            s["status"] = "Expedition"

func _abort_expedition(eid, return_loot = false):
    var exp: Variant = _find_expedition(eid)
    if exp == null:
        return
    if return_loot:
        _finish_expedition(eid)
        return
    for sid in exp["survivor_ids"]:
        var s: Variant = get_survivor(sid)
        if s != null and s["condition"] != "Dead":
            s["status"] = "Available"
            s["task"] = {}
    expeditions.erase(exp)
    save_game()
    state_changed.emit()

func _finish_expedition(eid):
    var exp: Variant = _find_expedition(eid)
    if exp == null:
        return
    if exp.get("special_site", "") != "":
        exp["state"] = "pending"
        for sid in exp["survivor_ids"]:
            var s0: Variant = get_survivor(sid)
            if s0 != null:
                s0["status"] = "Pending Expedition Event"
        _queue_event(_build_special_site_event(exp["special_site"], exp))
        return

    var zone = exp["zone"]
    var log_bits = []
    _resolve_routine_danger(exp, log_bits)
    var living_party = []
    for sid in exp["survivor_ids"]:
        var s: Variant = get_survivor(sid)
        if s != null and s["condition"] != "Dead":
            living_party.append(s)
    if living_party.is_empty():
        expeditions.erase(exp)
        _check_game_over()
        save_game()
        state_changed.emit()
        return

    var loot = _roll_loot(exp, living_party)
    for key in loot.keys():
        resources[key] = int(resources.get(key, 0)) + int(loot[key])
    var gear_found = _roll_gear(exp, living_party)
    if gear_found != "":
        inventory_gear.append(gear_found)
        log_bits.append("Found %s" % gear_found)

    zone_pressure[zone] = int(zone_pressure.get(zone, 0)) + int(D.ZONES[zone]["pressure"])
    zone_successes[zone] = int(zone_successes.get(zone, 0)) + 1
    _check_zone_unlock(zone)

    for s in living_party:
        s["status"] = "Available"
        s["task"] = {}
        s["fatigue"] = min(100.0, float(s["fatigue"]) + float(D.ZONES[zone]["fatigue"]))
        s["expeditions_done"] = int(s.get("expeditions_done", 0)) + 1
        var sxp = {"Camp Perimeter": 3, "Nearby Streets": 5, "Residential Blocks": 7, "Commercial Fringe": 9, "Industrial Edge": 11}[zone]
        var survxp = {"Camp Perimeter": 1, "Nearby Streets": 2, "Residential Blocks": 3, "Commercial Fringe": 4, "Industrial Edge": 6}[zone]
        add_skill_xp(s, "Scavenging", sxp)
        add_skill_xp(s, "Survival", survxp)
        s["history"].append("Day %d — Returned from %s." % [day, zone])
    if living_party.size() == 2:
        _change_relationship(living_party[0], living_party[1], 2)
        _change_relationship(living_party[1], living_party[0], 2)

    var loot_text = []
    for key in loot.keys():
        if int(loot[key]) > 0:
            loot_text.append("+%d %s" % [loot[key], key])
    var names = _party_names(exp["survivor_ids"])
    _add_history("Day %d — %s returned from %s (%s)." % [day, names, zone, ", ".join(loot_text)])
    toast_requested.emit("%s returned: %s" % [names, ", ".join(loot_text)])
    expeditions.erase(exp)
    _check_game_over()
    save_game()
    state_changed.emit()

func _resolve_routine_danger(exp, log_bits):
    var zone = exp["zone"]
    var chance = {"Camp Perimeter": 0.0, "Nearby Streets": 0.05, "Residential Blocks": 0.15, "Commercial Fringe": 0.25, "Industrial Edge": 0.35}[zone]
    if rng.randf() >= chance:
        return
    var dc = {"Nearby Streets": 8, "Residential Blocks": 10, "Commercial Fringe": 13, "Industrial Edge": 15}.get(zone, 7)
    var best_survival: Variant = null
    for sid in exp["survivor_ids"]:
        var s: Variant = get_survivor(sid)
        if s != null and s["condition"] != "Dead":
            if best_survival == null or int(s["skills"]["Survival"]) > int(best_survival["skills"]["Survival"]):
                best_survival = s
    if best_survival == null:
        return
    var result = skill_check(best_survival, "Survival", dc)
    if result >= 1:
        log_bits.append("Avoided trouble")
        return
    var target: Variant = get_survivor(exp["survivor_ids"][rng.randi_range(0, exp["survivor_ids"].size() - 1)])
    if target == null or target["condition"] == "Dead":
        return
    var combat_bonus = _equipment_combat_bonus(target)
    var combat_result = skill_check(target, "Combat", dc, combat_bonus)
    add_skill_xp(target, "Combat", rng.randi_range(5, 10))
    if combat_result >= 1:
        log_bits.append("Fought off danger")
    elif zone == "Nearby Streets":
        _apply_injury(target, "Hurt")
    elif zone == "Residential Blocks":
        _apply_injury(target, "Wounded" if combat_result < 0 else "Hurt")
    elif zone == "Commercial Fringe":
        _apply_injury(target, "Critical" if combat_result < 0 else "Wounded")
    elif zone == "Industrial Edge":
        if combat_result < 0 and (target["condition"] == "Wounded" or float(target["fatigue"]) >= 80.0) and rng.randf() < 0.18:
            _kill_survivor(target, "was killed during an expedition to the Industrial Edge")
        else:
            _apply_injury(target, "Critical" if combat_result < 1 else "Wounded")

func _equipment_combat_bonus(s):
    var weapon = s["equipment"].get("Weapon", "")
    if weapon == "" or not D.GEAR.has(weapon):
        return 0
    var data = D.GEAR[weapon]
    if data.has("ammo"):
        var needed = int(data["ammo"])
        if int(resources.get("Ammo", 0)) >= needed:
            resources["Ammo"] -= needed
            return int(data.get("combat", 0))
        return 1
    return int(data.get("combat", 0))

func _apply_injury(s, severity):
    if s == null or s["condition"] == "Dead":
        return
    var protection = 0.0
    var clothing = s["equipment"].get("Clothing", "")
    if clothing != "" and D.GEAR.has(clothing):
        protection = float(D.GEAR[clothing].get("protect", 0.0))
    if rng.randf() < protection:
        if severity == "Critical": severity = "Wounded"
        elif severity == "Wounded": severity = "Hurt"
        elif severity == "Hurt": return
    if severity == "Hurt":
        if s["condition"] == "Healthy":
            s["condition"] = "Hurt"
            s["injury_remaining"] = 60.0
    elif severity == "Wounded":
        if s["condition"] == "Critical":
            return
        s["condition"] = "Wounded"
        s["injury_remaining"] = 180.0
    elif severity == "Critical":
        if s["condition"] == "Critical":
            _kill_survivor(s, "died from accumulated injuries")
            return
        s["condition"] = "Critical"
        s["injury_remaining"] = 0.0
    s["stress"] = min(100.0, float(s["stress"]) + (5.0 if severity == "Hurt" else 12.0))
    s["history"].append("Day %d — Was %s." % [day, severity.to_lower()])

func _kill_survivor(s, reason):
    if s == null or s["condition"] == "Dead":
        return
    s["condition"] = "Dead"
    s["status"] = "Dead"
    s["task"] = {}
    s["history"].append("Day %d — Died: %s." % [day, reason])
    _add_history("Day %d — %s %s." % [day, s["name"], reason])
    for other in survivors:
        if other["condition"] == "Dead" or int(other["id"]) == int(s["id"]):
            continue
        var rel = int(other["relationships"].get(str(s["id"]), 0))
        if rel >= 60:
            other["stress"] = min(100.0, float(other["stress"]) + 25.0)
        elif rel >= 25:
            other["stress"] = min(100.0, float(other["stress"]) + 15.0)
    if coordinator_id == int(s["id"]):
        coordinator_id = -1
        if leadership_form == "Coordinator": leadership_form = "None"
    if leader_id == int(s["id"]):
        leader_id = -1
        leadership_form = "None"
    _check_game_over()

func _roll_loot(exp, party):
    var zone = exp["zone"]
    var base_rolls = int(D.ZONES[zone]["loot_rolls"])
    var pressure = int(zone_pressure.get(zone, 0))
    if pressure >= 85:
        base_rolls = max(1, base_rolls - 3)
    elif pressure >= 60:
        base_rolls = max(1, base_rolls - 2)
    elif pressure >= 30:
        base_rolls = max(1, base_rolls - 1)
    var best_scav = 0
    for s in party:
        best_scav = max(best_scav, int(s["skills"]["Scavenging"]))
    if best_scav >= 3: base_rolls += 1
    if best_scav >= 6: base_rolls += 1
    var capacity = 0
    for s in party:
        capacity += _pack_capacity(s)
    var loot = {}
    var used = 0
    for i in range(base_rolls):
        var key = _weighted_loot_pick(zone, exp["focus"])
        var qty = _loot_quantity(zone)
        qty = min(qty, capacity - used)
        if qty <= 0:
            break
        loot[key] = int(loot.get(key, 0)) + qty
        used += qty
    var leader: Variant = get_survivor(leader_id)
    if leader != null and leader["leader_ability"] == "Provider" and used < capacity and rng.randf() < 0.25:
        var bonus_key = _weighted_loot_pick(zone, exp["focus"])
        loot[bonus_key] = int(loot.get(bonus_key, 0)) + 1
    return loot

func _weighted_loot_pick(zone, focus):
    var table = D.ZONES[zone]["loot"]
    var total = 0.0
    var weighted = []
    for key in table.keys():
        var w = float(table[key])
        if focus == "Food & Water" and ["Raw Food", "Cooked Food", "Dirty Water", "Clean Water"].has(key):
            w *= 2.0
        elif focus == "Materials" and ["Wood", "Scrap Metal", "Cloth", "Plastic", "Hardware"].has(key):
            w *= 1.75
        weighted.append([key, w])
        total += w
    var roll = rng.randf_range(0.0, total)
    var cursor = 0.0
    for entry in weighted:
        cursor += float(entry[1])
        if roll <= cursor:
            return entry[0]
    return weighted.back()[0]

func _loot_quantity(zone):
    var r = rng.randf()
    if zone == "Camp Perimeter":
        return 2 if r < 0.20 else 1
    if zone == "Nearby Streets":
        return 2 if r < 0.20 else 1
    if zone == "Residential Blocks":
        if r < 0.05: return 3
        if r < 0.35: return 2
        return 1
    if zone == "Commercial Fringe":
        if r < 0.10: return 3
        if r < 0.45: return 2
        return 1
    if r < 0.15: return 3
    if r < 0.55: return 2
    return 1

func _pack_capacity(s):
    var pack = s["equipment"].get("Pack", "")
    if pack != "" and D.GEAR.has(pack):
        return int(D.GEAR[pack].get("capacity", 3))
    return 3

func _roll_gear(exp, party):
    var zone = exp["zone"]
    var chance = {"Camp Perimeter": 0.01, "Nearby Streets": 0.04, "Residential Blocks": 0.10, "Commercial Fringe": 0.16, "Industrial Edge": 0.18}[zone]
    var best = 0
    for s in party:
        best = max(best, int(s["skills"]["Scavenging"]))
    chance += best * 0.015
    if exp["focus"] == "Gear":
        chance *= 2.0
    if int(zone_pressure.get(zone, 0)) >= 60:
        chance *= 0.65
    chance = min(chance, 0.35)
    if rng.randf() > chance:
        return ""
    var pool = []
    if zone == "Camp Perimeter":
        pool = ["Work Gloves"]
    elif zone == "Nearby Streets":
        pool = ["Kitchen Knife", "Work Gloves", "Heavy Boots", "School Backpack"]
    elif zone == "Residential Blocks":
        pool = ["Kitchen Knife", "Baseball Bat", "Flashlight", "Screwdriver Set", "First Aid Kit", "School Backpack", "Leather Jacket"]
    elif zone == "Commercial Fringe":
        pool = ["Crowbar", "Hatchet", "Flashlight", "Bolt Cutters", "Toolbox", "First Aid Kit", "Pistol", "Hiking Pack", "Leather Jacket"]
    else:
        pool = ["Crowbar", "Hatchet", "Bolt Cutters", "Toolbox", "Pistol", "Shotgun", "Hiking Pack", "Heavy Boots", "Work Jacket"]
    return pool[rng.randi_range(0, pool.size() - 1)]

func _check_zone_unlock(zone):
    if not D.ZONE_SUCCESS_TO_UNLOCK.has(zone):
        return
    if int(zone_successes[zone]) < int(D.ZONE_SUCCESS_TO_UNLOCK[zone]):
        return
    var idx = D.ZONE_ORDER.find(zone)
    if idx >= 0 and idx + 1 < D.ZONE_ORDER.size():
        var next_zone = D.ZONE_ORDER[idx + 1]
        if not unlocked_zones.has(next_zone):
            unlocked_zones.append(next_zone)
            _add_history("Day %d — Route discovered: %s." % [day, next_zone])
            toast_requested.emit("New area discovered: %s" % next_zone)

func zone_loot_state(zone):
    var p = int(zone_pressure.get(zone, 0))
    if p >= 85: return "Picked Over"
    if p >= 60: return "Sparse"
    if p >= 30: return "Good"
    return "Rich"

func _daily_tick():
    var pop = population()
    var food_have = int(resources.get("Cooked Food", 0))
    var water_have = int(resources.get("Clean Water", 0))
    var food_missing = max(0, pop - food_have)
    var water_missing = max(0, pop - water_have)
    resources["Cooked Food"] = max(0, food_have - pop)
    resources["Clean Water"] = max(0, water_have - pop)

    if food_missing > 0:
        food_shortage_days += 1
        _apply_shortage("food", food_shortage_days)
    else:
        food_shortage_days = 0
    if water_missing > 0:
        water_shortage_days += 1
        _apply_shortage("water", water_shortage_days)
    else:
        water_shortage_days = 0

    if buildings.get("Rain Catcher", false):
        resources["Dirty Water"] = int(resources.get("Dirty Water", 0)) + 1
    if buildings.get("Garden Plot", false) and garden_tended_day == day:
        resources["Raw Food"] = int(resources.get("Raw Food", 0)) + 2

    for s in survivors:
        if s["condition"] == "Critical" and s["status"] != "Recovering" and rng.randf() < 0.25:
            _kill_survivor(s, "died from untreated critical injuries")
        if s["condition"] != "Dead" and population() > shelter_capacity():
            s["stress"] = min(100.0, float(s["stress"]) + 10.0)

    day += 1
    _add_history("Day %d began." % day)
    save_game()
    state_changed.emit()

func _apply_shortage(kind, consecutive):
    for s in survivors:
        if s["condition"] == "Dead":
            continue
        var stress_gain = 0
        var hurt_chance = 0.0
        if kind == "food":
            if consecutive == 1: stress_gain = 10
            elif consecutive == 2: stress_gain = 20; hurt_chance = 0.10
            else: stress_gain = 30; hurt_chance = 0.20
        else:
            if consecutive == 1: stress_gain = 15
            elif consecutive == 2: stress_gain = 25; hurt_chance = 0.20
            else: stress_gain = 40; hurt_chance = 0.40
        var leader: Variant = get_survivor(leader_id)
        if leader != null and leader["leader_ability"] == "Pragmatist" and consecutive == 1:
            stress_gain = int(stress_gain * 0.5)
            hurt_chance *= 0.5
        s["stress"] = min(100.0, float(s["stress"]) + stress_gain)
        if hurt_chance > 0.0 and rng.randf() < hurt_chance:
            _apply_injury(s, "Hurt")

func _party_names(ids):
    var names = []
    for sid in ids:
        var s: Variant = get_survivor(sid)
        if s != null:
            names.append(s["name"])
    return " & ".join(names)

# -----------------------------------------------------------------------------
# EVENTS
# -----------------------------------------------------------------------------

func _queue_event(event):
    if event.is_empty():
        return
    if current_event.is_empty():
        current_event = event
        event_changed.emit()
    else:
        event_queue.append(event)

func _advance_event_queue():
    if event_queue.is_empty():
        current_event = {}
    else:
        current_event = event_queue.pop_front()
    event_changed.emit()
    save_game()

func resolve_event(choice_index):
    if current_event.is_empty():
        return
    var choices = current_event.get("choices", [])
    if choice_index < 0 or choice_index >= choices.size():
        return
    var choice = choices[choice_index]
    if choice.get("disabled", false):
        return
    var event = current_event.duplicate(true)
    var action = choice.get("action", "close")
    _handle_event_action(event, action)
    if current_event == event or current_event.get("uid", "") == event.get("uid", ""):
        _advance_event_queue()
    save_game()
    state_changed.emit()

func _event_base(key, title, body, choices, context = {}):
    return {
        "uid": "%s_%d_%d" % [key, day, rng.randi()],
        "key": key,
        "title": title,
        "body": body,
        "choices": choices,
        "context": context.duplicate(true),
    }

func _build_field_event(key, exp):
    var context = {"expedition_id": exp["id"], "survivor_ids": exp["survivor_ids"], "zone": exp["zone"]}
    var lead: Variant = get_survivor(exp["survivor_ids"][0])
    if lead == null:
        return {}
    if key == "backpack":
        return _event_base(key, "The Backpack", "%s spots a backpack lying in the road. Nothing around it moves." % lead["name"], [
            {"text": "Grab it quickly", "action": "backpack_grab"},
            {"text": "Watch the street first", "action": "backpack_watch"},
            {"text": "Leave it", "action": "resume"},
        ], context)
    if key == "someone_inside":
        return _event_base(key, "Someone Inside", "Movement shifts behind the curtains of a house that looked abandoned." , [
            {"text": "Call out", "action": "inside_call"},
            {"text": "Enter quietly", "action": "inside_quiet"},
            {"text": "Leave", "action": "resume"},
        ], context)
    if key == "injured_stranger":
        return _event_base(key, "The Injured Stranger", "A lone survivor is sitting against a wall with a badly injured leg. They are alert, frightened, and clearly unable to travel far alone.", [
            {"text": "Help them back to First Fire", "action": "stranger_help"},
            {"text": "Treat them here", "action": "stranger_treat"},
            {"text": "Give them supplies and leave", "action": "stranger_supply", "disabled": int(resources.get("Cooked Food", 0)) < 1},
            {"text": "Leave them", "action": "resume"},
        ], context)
    if key == "dog":
        return _event_base(key, "The Dog", "A thin dog watches from half a block away. It looks at %s, then back toward an alley." % lead["name"], [
            {"text": "Follow it", "action": "dog_follow"},
            {"text": "Feed it", "action": "dog_feed", "disabled": int(resources.get("Cooked Food", 0)) < 1},
            {"text": "Ignore it", "action": "resume"},
        ], context)
    if key == "locked_garage":
        var has_breach = _party_has_tool(exp["survivor_ids"], "Breach")
        return _event_base(key, "Locked Garage", "A detached garage looks untouched. Its side door is still locked.", [
            {"text": "Use a pry tool", "action": "garage_pry", "disabled": not has_breach},
            {"text": "Work the lock", "action": "garage_technical"},
            {"text": "Climb through the window", "action": "garage_window"},
            {"text": "Leave it", "action": "resume"},
        ], context)
    if key == "gunshot":
        return _event_base(key, "The Gunshot", "A single gunshot cracks somewhere nearby, followed by silence.", [
            {"text": "Investigate", "action": "gunshot_investigate"},
            {"text": "Watch from a distance", "action": "gunshot_watch"},
            {"text": "Move away", "action": "resume"},
        ], context)
    if key == "discover_market":
        return _discovery_event("Miller Street Market", "An old independent market sits behind a collapsed delivery truck. The rear stockroom entrance looks blocked rather than looted.", context)
    if key == "discover_clinic":
        return _discovery_event("Neighborhood Clinic", "A small neighborhood clinic has intact shutters and an unbroken rear door.", context)
    if key == "hardware_cage":
        return _discovery_event("Hardware Cage", "A stripped hardware store still has a locked contractor cage at the rear.", context)
    if key == "construction_trailer":
        return _discovery_event("Construction Trailer", "Behind a fenced worksite sits a contractor trailer that appears untouched.", context)
    if key == "locked_office":
        return _discovery_event("Locked Industrial Office", "An office inside the industrial complex has been barricaded from the inside.", context)
    if key == "patrol_car":
        return _event_base(key, "Abandoned Patrol Car", "A patrol car sits half on the curb. The doors are locked; a weapon rack is visible inside.", [
            {"text": "Break in", "action": "patrol_break"},
            {"text": "Inspect carefully first", "action": "patrol_inspect"},
            {"text": "Leave it", "action": "resume"},
        ], context)
    if key == "smoke":
        return _event_base(key, "Smoke in the Distance", "A thin column of smoke rises beyond the next block.", [
            {"text": "Investigate", "action": "smoke_investigate"},
            {"text": "Mark the direction and continue", "action": "smoke_mark"},
            {"text": "Ignore it", "action": "resume"},
        ], context)
    if key == "barricade":
        return _event_base(key, "The Barricade", "Someone has deliberately blocked the route with shopping carts and sheet metal. Two armed strangers step into view.", [
            {"text": "Talk", "action": "barricade_talk"},
            {"text": "Back away", "action": "resume"},
            {"text": "Stand your ground", "action": "barricade_stand"},
        ], context)
    return {}

func _discovery_event(site, body, context):
    return _event_base("discover_site", site, body, [
        {"text": "Mark the location", "action": "mark_site:%s" % site},
        {"text": "Leave it for now", "action": "resume"},
    ], context)

func _build_special_site_event(site, exp):
    var context = {"expedition_id": exp["id"], "survivor_ids": exp["survivor_ids"], "site": site, "zone": exp["zone"]}
    if site == "Miller Street Market":
        return _event_base("site_market", site, "The store itself is wrecked, but the stockroom is still sealed behind shelving. Something scratches intermittently on the other side.", [
            {"text": "Clear the stockroom carefully", "action": "site_market_careful"},
            {"text": "Force it open fast", "action": "site_market_force"},
            {"text": "Turn back", "action": "site_retreat"},
        ], context)
    if site == "Neighborhood Clinic":
        return _event_base("site_clinic", site, "The clinic is dark and dusty. Cabinets remain closed, and a faint sound comes from the storage room.", [
            {"text": "Search the medical cabinets", "action": "site_clinic_search"},
            {"text": "Call toward the storage room", "action": "site_clinic_call"},
            {"text": "Turn back", "action": "site_retreat"},
        ], context)
    if site == "Hardware Cage":
        return _event_base("site_hardware", site, "The contractor cage is packed with boxes behind heavy chain-link.", [
            {"text": "Open the cage", "action": "site_hardware_open"},
            {"text": "Turn back", "action": "site_retreat"},
        ], context)
    if site == "Construction Trailer":
        return _event_base("site_construction", site, "The trailer contains shelving, job boxes, rolled plans and the stale smell of a place abandoned mid-shift.", [
            {"text": "Strip useful construction supplies", "action": "site_construction_loot"},
            {"text": "Check the locked back room", "action": "site_construction_room"},
            {"text": "Turn back", "action": "site_retreat"},
        ], context)
    if site == "Locked Industrial Office":
        return _event_base("site_office", site, "The barricade shifts when you knock. Someone is definitely alive inside.", [
            {"text": "Talk to them", "action": "site_office_talk"},
            {"text": "Force the door", "action": "site_office_force"},
            {"text": "Turn back", "action": "site_retreat"},
        ], context)
    return {}

func _party_has_tool(ids, tool_kind):
    for sid in ids:
        var s: Variant = get_survivor(sid)
        if s == null:
            continue
        for slot in ["Weapon", "Tool"]:
            var gear = s["equipment"].get(slot, "")
            if gear != "" and D.GEAR.has(gear) and D.GEAR[gear].get("tool", "") == tool_kind:
                return true
    return false

func _lead_from_event(event) -> Variant:
    var ids = event.get("context", {}).get("survivor_ids", [])
    if ids.is_empty():
        return null
    return get_survivor(ids[0])

func _finish_event_expedition(event, resume = true):
    var eid = int(event.get("context", {}).get("expedition_id", -1))
    if eid < 0:
        return
    if resume:
        _resume_expedition(eid)
    else:
        _abort_expedition(eid, false)

func _handle_event_action(event, action):
    var lead: Variant = _lead_from_event(event)
    var ids = event.get("context", {}).get("survivor_ids", [])
    var eid = int(event.get("context", {}).get("expedition_id", -1))

    if action == "resume":
        _finish_event_expedition(event, true)
        return
    if action.begins_with("mark_site:"):
        var site = action.trim_prefix("mark_site:")
        if special_sites.has(site):
            special_sites[site]["discovered"] = true
            _add_history("Day %d — %s discovered %s." % [day, lead["name"] if lead != null else "A survivor", site])
            toast_requested.emit("Special site discovered: %s" % site)
        _finish_event_expedition(event, true)
        return

    match action:
        "backpack_grab":
            if lead != null and rng.randf() < 0.70:
                inventory_gear.append("School Backpack")
                resources["Cooked Food"] += 1
                toast_requested.emit("Found a School Backpack and food.")
            else:
                if lead != null: _apply_injury(lead, "Hurt")
            _finish_event_expedition(event, true)
        "backpack_watch":
            if lead != null:
                var r = skill_check(lead, "Survival", 8)
                add_skill_xp(lead, "Survival", 4)
                if r >= 0:
                    inventory_gear.append("School Backpack")
                    toast_requested.emit("Careful observation paid off: School Backpack recovered.")
                else:
                    lead["stress"] = min(100.0, float(lead["stress"]) + 3.0)
            _finish_event_expedition(event, true)
        "inside_call":
            if rng.randf() < 0.55 and population() < shelter_capacity() + 1:
                _add_recruit("", ids)
            elif lead != null:
                lead["stress"] = min(100.0, float(lead["stress"]) + 4.0)
            _finish_event_expedition(event, true)
        "inside_quiet":
            if lead != null:
                var r2 = skill_check(lead, "Survival", 10)
                if r2 >= 1 and rng.randf() < 0.55 and population() < shelter_capacity() + 1:
                    _add_recruit("", ids)
                elif r2 < 0:
                    _apply_injury(lead, "Hurt")
            _finish_event_expedition(event, true)
        "stranger_help":
            if population() < shelter_capacity() + 1:
                _add_recruit("", ids)
                for sid in ids:
                    var s1: Variant = get_survivor(sid)
                    if s1 != null: s1["fatigue"] = min(100.0, float(s1["fatigue"]) + 8.0)
            else:
                toast_requested.emit("There is no room to bring them back safely.")
            _finish_event_expedition(event, true)
        "stranger_treat":
            if lead != null:
                var r3 = skill_check(lead, "Medical", 10)
                add_skill_xp(lead, "Medical", 8)
                if r3 >= 0 and population() < shelter_capacity() + 1:
                    _add_recruit("", ids)
                elif r3 < 0:
                    lead["stress"] = min(100.0, float(lead["stress"]) + 5.0)
            _finish_event_expedition(event, true)
        "stranger_supply":
            if int(resources["Cooked Food"]) > 0:
                resources["Cooked Food"] -= 1
                flags["helped_injured_stranger"] = true
                if lead != null: _change_reputation(lead, 2)
            _finish_event_expedition(event, true)
        "dog_follow":
            if rng.randf() < 0.50:
                resources["Cooked Food"] += 2
                resources["Hardware"] += 1
                toast_requested.emit("The dog led the party to a small cache.")
            elif rng.randf() < 0.50 and population() < shelter_capacity() + 1:
                _add_recruit("", ids)
            elif lead != null:
                lead["stress"] = min(100.0, float(lead["stress"]) + 4.0)
            flags["met_dog"] = true
            _finish_event_expedition(event, true)
        "dog_feed":
            if int(resources["Cooked Food"]) > 0:
                resources["Cooked Food"] -= 1
                flags["fed_dog"] = true
                if lead != null: lead["stress"] = max(0.0, float(lead["stress"]) - 5.0)
            _finish_event_expedition(event, true)
        "garage_pry":
            resources["Scrap Metal"] += rng.randi_range(2, 4)
            resources["Hardware"] += rng.randi_range(1, 3)
            if rng.randf() < 0.25: inventory_gear.append("Toolbox")
            _finish_event_expedition(event, true)
        "garage_technical":
            if lead != null:
                var r4 = skill_check(lead, "Technical", 10)
                add_skill_xp(lead, "Technical", 6)
                if r4 >= 0:
                    resources["Scrap Metal"] += 2
                    resources["Hardware"] += 2
                else:
                    lead["stress"] += 3
            _finish_event_expedition(event, true)
        "garage_window":
            if lead != null:
                var r5 = skill_check(lead, "Survival", 9)
                if r5 < 0: _apply_injury(lead, "Hurt")
                else:
                    resources["Hardware"] += 2
                    if rng.randf() < 0.30: inventory_gear.append("Screwdriver Set")
            _finish_event_expedition(event, true)
        "gunshot_investigate":
            var r6 = rng.randf()
            if r6 < 0.50 and population() < shelter_capacity() + 1:
                _add_recruit("", ids)
                if lead != null: _change_reputation(lead, 4)
            elif r6 < 0.75:
                resources["Ammo"] += rng.randi_range(1, 3)
            elif r6 < 0.90 and lead != null:
                _apply_injury(lead, "Hurt")
            _finish_event_expedition(event, true)
        "gunshot_watch":
            if lead != null:
                add_skill_xp(lead, "Survival", 3)
                if rng.randf() < 0.35:
                    resources["Ammo"] += 1
            _finish_event_expedition(event, true)
        "patrol_break":
            if rng.randf() < 0.55:
                inventory_gear.append("Pistol")
                resources["Ammo"] += rng.randi_range(1, 3)
            elif lead != null:
                _apply_injury(lead, "Hurt")
            _finish_event_expedition(event, true)
        "patrol_inspect":
            if lead != null:
                var r7 = skill_check(lead, "Survival", 11)
                if r7 >= 0:
                    inventory_gear.append("Pistol")
                    resources["Ammo"] += 2
                else:
                    lead["stress"] += 4
            _finish_event_expedition(event, true)
        "smoke_investigate":
            if rng.randf() < 0.45 and population() < shelter_capacity() + 1:
                _add_recruit("", ids)
            elif rng.randf() < 0.50:
                resources["Cooked Food"] += 2
            elif lead != null:
                _apply_injury(lead, "Hurt")
            _finish_event_expedition(event, true)
        "smoke_mark":
            flags["smoke_marked"] = true
            if lead != null: add_skill_xp(lead, "Survival", 2)
            _finish_event_expedition(event, true)
        "barricade_talk":
            if lead != null:
                var r8 = skill_check(lead, "Social", 12)
                add_skill_xp(lead, "Social", 8)
                if r8 >= 0:
                    resources["Cooked Food"] += 1
                    flags["met_barricade_group"] = true
                else:
                    lead["stress"] += 8
            _finish_event_expedition(event, true)
        "barricade_stand":
            if lead != null:
                var r9 = skill_check(lead, "Combat", 13, _equipment_combat_bonus(lead))
                add_skill_xp(lead, "Combat", 8)
                if r9 < 0: _apply_injury(lead, "Wounded")
                elif r9 == 0: _apply_injury(lead, "Hurt")
                else: resources["Ammo"] += 2
            _finish_event_expedition(event, true)
        "site_market_careful":
            resources["Cooked Food"] += rng.randi_range(4, 7)
            resources["Raw Food"] += rng.randi_range(1, 2)
            if rng.randf() < 0.30 and population() < shelter_capacity() + 1:
                _add_recruit("Cook", ids)
            _clear_site(event, true)
        "site_market_force":
            resources["Cooked Food"] += rng.randi_range(5, 8)
            if lead != null and rng.randf() < 0.35: _apply_injury(lead, "Hurt")
            _clear_site(event, true)
        "site_clinic_search":
            var med = 1
            if lead != null:
                med = 2 + int(lead["skills"]["Medical"] >= 3) + int(lead["skills"]["Medical"] >= 5)
                add_skill_xp(lead, "Medical", 10)
            resources["Medicine"] += med
            if rng.randf() < 0.25: inventory_gear.append("First Aid Kit")
            _clear_site(event, true)
        "site_clinic_call":
            if population() < shelter_capacity() + 1 and rng.randf() < 0.65:
                _add_recruit("Nursing Assistant", ids)
            else:
                resources["Medicine"] += 2
            _clear_site(event, true)
        "site_hardware_open":
            resources["Hardware"] += rng.randi_range(3, 6)
            resources["Scrap Metal"] += rng.randi_range(2, 4)
            if rng.randf() < 0.30: inventory_gear.append("Toolbox")
            _clear_site(event, true)
        "site_construction_loot":
            resources["Wood"] += 4
            resources["Hardware"] += 3
            resources["Scrap Metal"] += 2
            _clear_site(event, true)
        "site_construction_room":
            if population() < shelter_capacity() + 1 and rng.randf() < 0.40:
                _add_recruit("Construction Worker", ids)
            else:
                inventory_gear.append("Toolbox")
                resources["Hardware"] += 2
            _clear_site(event, true)
        "site_office_talk":
            if population() < shelter_capacity() + 1:
                _add_recruit("Mechanic", ids)
            else:
                resources["Hardware"] += 2
            _clear_site(event, true)
        "site_office_force":
            if lead != null:
                var rr = skill_check(lead, "Combat", 12, _equipment_combat_bonus(lead))
                if rr < 0: _apply_injury(lead, "Hurt")
            resources["Scrap Metal"] += 2
            resources["Hardware"] += 2
            _clear_site(event, true)
        "site_retreat":
            _finish_special_site_without_clear(event)
        "camp_sleep_newcomer":
            _resolve_sleep_event(event, "newcomer")
        "camp_sleep_existing":
            _resolve_sleep_event(event, "existing")
        "camp_sleep_rough":
            _resolve_sleep_event(event, "rough")
        "camp_run_best":
            _resolve_run_complaint(event, "best")
        "camp_run_rotate":
            policies["Expedition Duty"] = "Rotation"
            _resolve_run_complaint(event, "rotate")
        "camp_extra_food_give":
            if int(resources["Cooked Food"]) > 0:
                resources["Cooked Food"] -= 1
                if lead != null: lead["stress"] = max(0.0, float(lead["stress"]) - 10.0)
        "camp_extra_food_refuse":
            if lead != null: lead["stress"] = min(100.0, float(lead["stress"]) + 5.0)
        "camp_missing_search":
            flags["searched_missing_food"] = true
            if rng.randf() < 0.60:
                toast_requested.emit("The missing food was hidden among personal belongings.")
            else:
                toast_requested.emit("No proof turned up.")
        "camp_missing_ignore":
            pass
        "camp_fight_separate":
            _resolve_fight(event, "separate")
        "camp_fight_mediated":
            _resolve_fight(event, "mediate")
        "camp_fight_settle":
            _resolve_fight(event, "settle")
        "camp_refuse_rest":
            if lead != null:
                lead["status"] = "Resting"
                lead["stress"] = max(0.0, float(lead["stress"]) - 5.0)
        "camp_refuse_force":
            if lead != null:
                lead["stress"] = min(100.0, float(lead["stress"]) + 10.0)
                lead["leader_support"] = int(lead.get("leader_support", 0)) - 5
        "camp_outside_investigate":
            if lead != null and not buildings.get("Noise Line", false) and rng.randf() < 0.20:
                _apply_injury(lead, "Hurt")
            else:
                toast_requested.emit("Nothing made it into camp.")
        "camp_outside_wait":
            toast_requested.emit("The noise eventually fades.")
        "camp_request_give":
            if int(resources["Cloth"]) > 0:
                resources["Cloth"] -= 1
                if lead != null: lead["stress"] = max(0.0, float(lead["stress"]) - 8.0)
        "camp_request_refuse":
            if lead != null: lead["stress"] += 4
        "politics_support_a", "politics_support_b", "politics_neutral":
            _resolve_coordinator_vote(event, action)
        "election_support_a", "election_support_b", "election_neutral":
            _resolve_formal_election(event, action)
        "alpha_continue":
            alpha_complete_shown = true
        _:
            pass

func _clear_site(event, resume_after):
    var site = event.get("context", {}).get("site", "")
    if site != "" and special_sites.has(site):
        special_sites[site]["cleared"] = true
        _add_history("Day %d — %s was cleared." % [day, site])
    var eid = int(event.get("context", {}).get("expedition_id", -1))
    var exp: Variant = _find_expedition(eid)
    if exp != null:
        for sid in exp["survivor_ids"]:
            var s: Variant = get_survivor(sid)
            if s != null and s["condition"] != "Dead":
                s["status"] = "Available"
                s["task"] = {}
                s["fatigue"] = min(100.0, float(s["fatigue"]) + float(D.ZONES[exp["zone"]]["fatigue"]))
        expeditions.erase(exp)

func _finish_special_site_without_clear(event):
    var eid = int(event.get("context", {}).get("expedition_id", -1))
    var exp: Variant = _find_expedition(eid)
    if exp != null:
        for sid in exp["survivor_ids"]:
            var s: Variant = get_survivor(sid)
            if s != null:
                s["status"] = "Available"
                s["task"] = {}
        expeditions.erase(exp)

# -----------------------------------------------------------------------------
# CAMP EVENTS / POLITICS
# -----------------------------------------------------------------------------

func _consider_camp_event():
    if camp_event_cooldown > 0.0 or population() < 2 or game_over:
        return
    var avg_stress = 0.0
    var living = 0
    var tense = false
    for s in survivors:
        if s["condition"] == "Dead": continue
        avg_stress += float(s["stress"])
        living += 1
        for v in s["relationships"].values():
            if int(v) <= -25: tense = true
    if living > 0: avg_stress /= living
    var chance = 0.12 + (avg_stress / 7.0) * 0.01
    if population() > shelter_capacity(): chance += 0.05
    if food_shortage_days > 0 or water_shortage_days > 0: chance += 0.05
    if tense: chance += 0.05
    chance = min(0.40, chance)
    if rng.randf() > chance:
        return
    var ev = _select_camp_event()
    if not ev.is_empty():
        _queue_event(ev)
        camp_event_cooldown = 60.0

func _select_camp_event():
    var candidates = []
    if population() > shelter_capacity(): candidates.append("sleep")
    if _repeated_runner() != null: candidates.append("run")
    if int(resources.get("Cooked Food", 0)) > 0: candidates.append("extra_food")
    if population() >= 3 and int(resources.get("Cooked Food", 0)) > 0: candidates.append("missing")
    if _tense_pair().size() == 2: candidates.append("fight")
    if _high_stress_survivor() != null: candidates.append("refuse")
    candidates.append("outside")
    if int(resources.get("Cloth", 0)) > 0: candidates.append("request")
    if candidates.is_empty(): return {}
    var key = candidates[rng.randi_range(0, candidates.size() - 1)]
    if key == "sleep":
        return _event_base("camp_sleep", "Where Am I Sleeping?", "There are more people than proper sleeping spaces. Someone is going to have a miserable night unless the camp changes its priorities.", [
            {"text": "Give the newcomer the best spot", "action": "camp_sleep_newcomer"},
            {"text": "Ask an established survivor to give up theirs", "action": "camp_sleep_existing"},
            {"text": "The newcomer sleeps rough", "action": "camp_sleep_rough"},
        ])
    if key == "run":
        var s: Variant = _repeated_runner()
        return _event_base("camp_run", "Another Run?", "%s asks why they are always the one being sent outside while others stay at camp." % s["name"], [
            {"text": "You're the best at it", "action": "camp_run_best"},
            {"text": "Promise to rotate expedition duty", "action": "camp_run_rotate"},
        ], {"survivor_ids": [s["id"]]})
    if key == "extra_food":
        var target: Variant = _highest_stress_survivor()
        return _event_base("camp_extra_food", "Extra Food", "%s quietly asks for another ration." % target["name"], [
            {"text": "Give them one", "action": "camp_extra_food_give"},
            {"text": "Refuse", "action": "camp_extra_food_refuse"},
        ], {"survivor_ids": [target["id"]]})
    if key == "missing":
        resources["Cooked Food"] = max(0, int(resources["Cooked Food"]) - 1)
        return _event_base("camp_missing", "The Missing Can", "A ration is missing from the camp's food stores. Nobody admits taking it.", [
            {"text": "Search for what happened", "action": "camp_missing_search"},
            {"text": "Let it go", "action": "camp_missing_ignore"},
        ])
    if key == "fight":
        var pair = _tense_pair()
        return _event_base("camp_fight", "Fight at the Fire", "%s and %s finally come to blows beside the fire." % [pair[0]["name"], pair[1]["name"]], [
            {"text": "Separate them", "action": "camp_fight_separate"},
            {"text": "Have someone mediate", "action": "camp_fight_mediated"},
            {"text": "Let them settle it", "action": "camp_fight_settle"},
        ], {"pair": [pair[0]["id"], pair[1]["id"]]})
    if key == "refuse":
        var target2: Variant = _high_stress_survivor()
        return _event_base("camp_refuse", "Refusing Duty", "%s says they are done working for now." % target2["name"], [
            {"text": "Give them time to rest", "action": "camp_refuse_rest"},
            {"text": "Tell them everyone has to contribute", "action": "camp_refuse_force"},
        ], {"survivor_ids": [target2["id"]]})
    if key == "outside":
        var warning = "The Noise Line starts rattling before anything reaches camp." if buildings.get("Noise Line", false) else "Something moves just outside the sleeping area in the dark."
        var guard: Variant = _highest_skill_survivor("Survival")
        return _event_base("camp_outside", "Something Outside", warning, [
            {"text": "Investigate", "action": "camp_outside_investigate"},
            {"text": "Stay quiet and wait", "action": "camp_outside_wait"},
        ], {"survivor_ids": [guard["id"]] if guard != null else []})
    if key == "request":
        var requester: Variant = _highest_stress_survivor()
        return _event_base("camp_request", "A Personal Request", "%s asks for some cloth to repair a personal keepsake. It will not help the camp." % requester["name"], [
            {"text": "Give them the cloth", "action": "camp_request_give"},
            {"text": "We need it for the camp", "action": "camp_request_refuse"},
        ], {"survivor_ids": [requester["id"]]})
    return {}

func _repeated_runner() -> Variant:
    if recent_expedition_ids.size() < 4:
        return null
    var counts = {}
    for sid in recent_expedition_ids:
        counts[str(sid)] = int(counts.get(str(sid), 0)) + 1
    for key in counts.keys():
        if int(counts[key]) >= 3:
            var s: Variant = get_survivor(int(key))
            if s != null and population() >= 2:
                return s
    return null

func _tense_pair():
    for a in survivors:
        if a["condition"] == "Dead": continue
        for b in survivors:
            if b["condition"] == "Dead" or int(a["id"]) >= int(b["id"]): continue
            if int(a["relationships"].get(str(b["id"]), 0)) <= -25 or int(b["relationships"].get(str(a["id"]), 0)) <= -25:
                return [a, b]
    return []

func _high_stress_survivor() -> Variant:
    for s in survivors:
        if s["condition"] != "Dead" and (float(s["stress"]) >= 80.0 or float(s["fatigue"]) >= 85.0):
            return s
    return null

func _highest_stress_survivor() -> Variant:
    var best: Variant = null
    for s in survivors:
        if s["condition"] == "Dead": continue
        if best == null or float(s["stress"]) > float(best["stress"]): best = s
    return best

func _highest_skill_survivor(skill) -> Variant:
    var best: Variant = null
    for s in survivors:
        if s["condition"] == "Dead": continue
        if best == null or int(s["skills"][skill]) > int(best["skills"][skill]): best = s
    return best

func _resolve_sleep_event(event, mode):
    var living = []
    for s in survivors:
        if s["condition"] != "Dead": living.append(s)
    if living.is_empty(): return
    var newcomer = living.back()
    if mode == "newcomer":
        newcomer["stress"] = max(0.0, float(newcomer["stress"]) - 5.0)
        if living.size() > 1: living[0]["stress"] = min(100.0, float(living[0]["stress"]) + 5.0)
    elif mode == "existing":
        newcomer["stress"] = max(0.0, float(newcomer["stress"]) - 3.0)
        if living.size() > 1: living[0]["stress"] += 8
    else:
        newcomer["stress"] += 10

func _resolve_run_complaint(event, mode):
    var s: Variant = _lead_from_event(event)
    if s == null: return
    if mode == "best":
        s["stress"] = min(100.0, float(s["stress"]) + 6.0)
        s["leader_support"] = int(s.get("leader_support", 0)) - 2
    else:
        s["stress"] = max(0.0, float(s["stress"]) - 5.0)
        flags["promised_rotation"] = true

func _resolve_fight(event, mode):
    var pair_ids = event.get("context", {}).get("pair", [])
    if pair_ids.size() != 2: return
    var a: Variant = get_survivor(pair_ids[0])
    var b: Variant = get_survivor(pair_ids[1])
    if a == null or b == null: return
    if mode == "mediate":
        var med: Variant = _highest_skill_survivor("Social")
        if med != null and skill_check(med, "Social", 10) >= 0:
            _change_relationship(a, b, 8)
            _change_relationship(b, a, 8)
            add_skill_xp(med, "Social", 8)
        else:
            _change_relationship(a, b, -4)
            _change_relationship(b, a, -4)
    elif mode == "separate":
        _change_relationship(a, b, -2)
        _change_relationship(b, a, -2)
    else:
        _change_relationship(a, b, -8)
        _change_relationship(b, a, -8)
        if rng.randf() < 0.50: _apply_injury(a if rng.randf() < 0.5 else b, "Hurt")

func _consider_politics():
    if game_over:
        return
    if population() >= 3 and coordinator_id == -1 and leader_id == -1 and not flags.get("coordinator_event_queued", false):
        flags["coordinator_event_queued"] = true
        _queue_event(_build_coordinator_event())
    if population() >= 5 and leader_id == -1 and coordinator_id != -1 and not flags.get("formal_election_queued", false):
        flags["formal_election_queued"] = true
        _queue_event(_build_formal_election())

func _candidate_standing(s):
    var rel_sum = 0
    var rel_count = 0
    for other in survivors:
        if other["condition"] == "Dead" or int(other["id"]) == int(s["id"]): continue
        rel_sum += int(other["relationships"].get(str(s["id"]), 0))
        rel_count += 1
    var avg = float(rel_sum) / rel_count if rel_count > 0 else 0.0
    return int(s["skills"]["Social"]) * 6 + int(s["reputation"]) + int(clamp(avg * 0.5, -25.0, 25.0))

func _top_candidates():
    var living = []
    for s in survivors:
        if s["condition"] != "Dead": living.append(s)
    living.sort_custom(func(a, b): return _candidate_standing(a) > _candidate_standing(b))
    if living.size() >= 2: return [living[0], living[1]]
    return living

func _build_coordinator_event():
    var c = _top_candidates()
    if c.size() < 2: return {}
    return _event_base("politics_coordinator", "Who Decides?", "The camp has grown past one person making every call by habit. When people disagree, someone needs the final word.", [
        {"text": "Support %s — %s" % [c[0]["name"], c[0]["leader_ability"]], "action": "politics_support_a"},
        {"text": "Support %s — %s" % [c[1]["name"], c[1]["leader_ability"]], "action": "politics_support_b"},
        {"text": "Stay out of it", "action": "politics_neutral"},
    ], {"candidates": [c[0]["id"], c[1]["id"]]})

func _resolve_coordinator_vote(event, action):
    var ids = event.get("context", {}).get("candidates", [])
    if ids.size() < 2: return
    var endorsement = -1
    if action == "politics_support_a": endorsement = ids[0]
    elif action == "politics_support_b": endorsement = ids[1]
    var winner = _run_vote(ids, endorsement)
    coordinator_id = winner
    leadership_form = "Coordinator"
    var s: Variant = get_survivor(winner)
    if s != null:
        _add_history("Day %d — %s became First Fire's coordinator (%s)." % [day, s["name"], s["leader_ability"]])
        toast_requested.emit("%s is now Coordinator." % s["name"])

func _build_formal_election():
    var incumbent: Variant = get_survivor(coordinator_id)
    var candidates = _top_candidates()
    var challenger: Variant = null
    for c in candidates:
        if incumbent == null or int(c["id"]) != int(incumbent["id"]):
            challenger = c
            break
    if incumbent == null or challenger == null:
        return {}
    return _event_base("politics_election", "Make It Official", "Five people now depend on this camp. The informal arrangement is no longer enough. The camp calls for a formal leader.", [
        {"text": "Support %s — %s" % [incumbent["name"], incumbent["leader_ability"]], "action": "election_support_a"},
        {"text": "Support %s — %s" % [challenger["name"], challenger["leader_ability"]], "action": "election_support_b"},
        {"text": "Stay neutral", "action": "election_neutral"},
    ], {"candidates": [incumbent["id"], challenger["id"]]})

func _resolve_formal_election(event, action):
    var ids = event.get("context", {}).get("candidates", [])
    if ids.size() < 2: return
    var endorsement = -1
    if action == "election_support_a": endorsement = ids[0]
    elif action == "election_support_b": endorsement = ids[1]
    leader_id = _run_vote(ids, endorsement)
    coordinator_id = -1
    leadership_form = "Elected Leader"
    var winner: Variant = get_survivor(leader_id)
    if winner != null:
        _add_history("Day %d — %s was elected leader of First Fire (%s)." % [day, winner["name"], winner["leader_ability"]])
        toast_requested.emit("%s was elected leader." % winner["name"])

func _run_vote(candidate_ids, endorsement):
    var totals = {}
    for cid in candidate_ids: totals[str(cid)] = 0
    for voter in survivors:
        if voter["condition"] == "Dead": continue
        var best_id = candidate_ids[0]
        var best_score = -99999
        for cid in candidate_ids:
            var c: Variant = get_survivor(cid)
            if c == null: continue
            var score = int(voter["relationships"].get(str(cid), 0)) + int(c["skills"]["Social"]) * 6 + int(c["reputation"])
            if int(voter["id"]) == int(cid): score += 50
            if int(cid) == int(endorsement): score += 15
            score += rng.randi_range(-8, 8)
            if score > best_score:
                best_score = score
                best_id = cid
        totals[str(best_id)] = int(totals.get(str(best_id), 0)) + 1
    var winner = candidate_ids[0]
    for cid in candidate_ids:
        if int(totals[str(cid)]) > int(totals[str(winner)]): winner = cid
        elif int(totals[str(cid)]) == int(totals[str(winner)]) and _candidate_standing(get_survivor(cid)) > _candidate_standing(get_survivor(winner)):
            winner = cid
    return int(winner)

func leader_support_label():
    var leader: Variant = get_survivor(leader_id if leader_id != -1 else coordinator_id)
    if leader == null: return "None"
    var sum = 0.0
    var count = 0
    for s in survivors:
        if s["condition"] == "Dead" or int(s["id"]) == int(leader["id"]): continue
        sum += int(s["relationships"].get(str(leader["id"]), 0)) + int(s.get("leader_support", 0))
        count += 1
    var avg = sum / count if count > 0 else 0.0
    if avg >= 50: return "Very Strong"
    if avg >= 20: return "Strong"
    if avg <= -40: return "Hostile"
    if avg <= -15: return "Weak"
    return "Mixed"

func _check_alpha_complete():
    if alpha_complete:
        return
    if population() >= 5 and buildings.get("Rain Catcher", false) and buildings.get("Workbench", false) and buildings.get("Sewing Table", false) and buildings.get("Cabin", false) and leader_id != -1:
        alpha_complete = true
        _add_history("Day %d — First Fire became a real camp." % day)
        _queue_event(_event_base("alpha_complete", "A REAL CAMP", "Five people sleep behind the same walls tonight. Nobody would mistake this for civilization. But it isn't just a campfire anymore.", [
            {"text": "Continue playing", "action": "alpha_continue"}
        ]))

func _check_game_over():
    if population() <= 0:
        game_over = true
        sim_paused = true
        _queue_event(_event_base("game_over", "FIRST FIRE IS GONE", "No one remains to keep the fire burning.", [
            {"text": "Close", "action": "close"}
        ]))

func _add_history(line):
    history.append(line)
    if history.size() > 200:
        history.pop_front()

# -----------------------------------------------------------------------------
# SAVE / LOAD
# -----------------------------------------------------------------------------

func save_game():
    if not initialized and survivors.is_empty():
        return
    var data = {
        "version": "0.1.0",
        "day": day, "day_elapsed": day_elapsed,
        "resources": resources, "components": components, "inventory_gear": inventory_gear,
        "buildings": buildings, "survivors": survivors,
        "next_survivor_id": next_survivor_id, "next_expedition_id": next_expedition_id,
        "expeditions": expeditions, "zone_successes": zone_successes, "zone_pressure": zone_pressure,
        "unlocked_zones": unlocked_zones, "special_sites": special_sites,
        "history": history, "flags": flags, "policies": policies,
        "current_event": current_event, "event_queue": event_queue,
        "coordinator_id": coordinator_id, "leader_id": leader_id, "leadership_form": leadership_form,
        "eligible_expeditions_since_recruit": eligible_expeditions_since_recruit,
        "food_shortage_days": food_shortage_days, "water_shortage_days": water_shortage_days,
        "garden_tended_day": garden_tended_day,
        "game_over": game_over, "alpha_complete": alpha_complete, "alpha_complete_shown": alpha_complete_shown,
        "recent_expedition_ids": recent_expedition_ids,
    }
    var file = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file != null:
        file.store_string(JSON.stringify(data))

func load_game():
    var file = FileAccess.open(SAVE_PATH, FileAccess.READ)
    if file == null:
        new_game()
        return
    var parsed = JSON.parse_string(file.get_as_text())
    if typeof(parsed) != TYPE_DICTIONARY:
        new_game()
        return
    day = int(parsed.get("day", 1))
    day_elapsed = float(parsed.get("day_elapsed", 0.0))
    resources = parsed.get("resources", D.STARTING_RESOURCES.duplicate(true))
    components = parsed.get("components", {})
    inventory_gear = parsed.get("inventory_gear", [])
    buildings = parsed.get("buildings", {})
    survivors = parsed.get("survivors", [])
    next_survivor_id = int(parsed.get("next_survivor_id", 1))
    next_expedition_id = int(parsed.get("next_expedition_id", 1))
    expeditions = parsed.get("expeditions", [])
    zone_successes = parsed.get("zone_successes", {})
    zone_pressure = parsed.get("zone_pressure", {})
    unlocked_zones = parsed.get("unlocked_zones", ["Camp Perimeter"])
    special_sites = parsed.get("special_sites", {})
    history = parsed.get("history", [])
    flags = parsed.get("flags", {})
    policies = parsed.get("policies", {})
    current_event = parsed.get("current_event", {})
    event_queue = parsed.get("event_queue", [])
    coordinator_id = int(parsed.get("coordinator_id", -1))
    leader_id = int(parsed.get("leader_id", -1))
    leadership_form = parsed.get("leadership_form", "None")
    eligible_expeditions_since_recruit = int(parsed.get("eligible_expeditions_since_recruit", 0))
    food_shortage_days = int(parsed.get("food_shortage_days", 0))
    water_shortage_days = int(parsed.get("water_shortage_days", 0))
    garden_tended_day = int(parsed.get("garden_tended_day", -1))
    game_over = bool(parsed.get("game_over", false))
    alpha_complete = bool(parsed.get("alpha_complete", false))
    alpha_complete_shown = bool(parsed.get("alpha_complete_shown", false))
    recent_expedition_ids = parsed.get("recent_expedition_ids", [])
    _normalize_loaded_state()
    # Returning to a saved game is always paused until the player explicitly resumes.
    sim_paused = true
    state_changed.emit()

func _normalize_loaded_state():
    # Alpha saves are allowed to survive code changes. Fill missing keys instead of
    # letting an older/incomplete save produce blank screens or null lookups.
    for key in D.RESOURCE_ORDER:
        if not resources.has(key):
            resources[key] = 0
    for key in ["Sterile Dressing", "Framing Kit", "Pack Frame", "Weatherproofing Roll"]:
        if not components.has(key):
            components[key] = 0

    if not buildings.has("Fire Pit"):
        buildings["Fire Pit"] = true
    if not buildings.has("Sleeping Bag"):
        buildings["Sleeping Bag"] = true
    for b in D.BUILD_ORDER:
        if not buildings.has(b):
            buildings[b] = false

    for z in D.ZONE_ORDER:
        if not zone_successes.has(z):
            zone_successes[z] = 0
        if not zone_pressure.has(z):
            zone_pressure[z] = 0
    if unlocked_zones.is_empty():
        unlocked_zones = ["Camp Perimeter"]

    for site in D.SPECIAL_SITES.keys():
        if not special_sites.has(site):
            special_sites[site] = {"discovered": false, "cleared": false}

    # Repair a pre-alpha malformed save rather than presenting an empty survivor tab.
    if survivors.is_empty() and not game_over:
        var founder = _generate_survivor(true)
        founder["equipment"] = {"Weapon": "Utility Knife", "Clothing": "", "Pack": "Worn Backpack", "Tool": ""}
        founder["history"].append("Day %d — Established First Fire." % day)
        survivors.append(founder)
        _add_history("Day %d — %s established First Fire." % [day, founder["name"]])

    var max_id = 0
    for s in survivors:
        max_id = max(max_id, int(s.get("id", 0)))
        if not s.has("skills"):
            s["skills"] = {"Combat": 1, "Scavenging": 1, "Survival": 1, "Medical": 1, "Technical": 1, "Social": 1}
        if not s.has("skill_xp"):
            s["skill_xp"] = {}
        for skill in ["Combat", "Scavenging", "Survival", "Medical", "Technical", "Social"]:
            if not s["skills"].has(skill):
                s["skills"][skill] = 1
            if not s["skill_xp"].has(skill):
                s["skill_xp"][skill] = 0
        if not s.has("traits"):
            s["traits"] = []
        if not s.has("equipment"):
            s["equipment"] = {"Weapon": "", "Clothing": "", "Pack": "", "Tool": ""}
        for slot in ["Weapon", "Clothing", "Pack", "Tool"]:
            if not s["equipment"].has(slot):
                s["equipment"][slot] = ""
        if not s.has("relationships"):
            s["relationships"] = {}
        if not s.has("history"):
            s["history"] = []
        if not s.has("leader_ability") or str(s["leader_ability"]) == "" or not D.LEADER_ABILITIES.has(str(s["leader_ability"])):
            s["leader_ability"] = _derive_leader_ability(s)
        if not s.has("status"):
            s["status"] = "Available"
        if not s.has("condition"):
            s["condition"] = "Healthy"
        if not s.has("task"):
            s["task"] = {}
        if not s.has("fatigue"):
            s["fatigue"] = 0.0
        if not s.has("stress"):
            s["stress"] = 0.0
        if not s.has("injury_remaining"):
            s["injury_remaining"] = 0.0
        if not s.has("reputation"):
            s["reputation"] = 0
        if not s.has("leader_support"):
            s["leader_support"] = 0
        if not s.has("expeditions_done"):
            s["expeditions_done"] = 0
    next_survivor_id = max(next_survivor_id, max_id + 1)
