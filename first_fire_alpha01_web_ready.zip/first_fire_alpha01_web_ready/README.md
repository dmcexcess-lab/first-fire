# First Fire — Alpha 0.1

A menu-driven zombie settlement prototype built in Godot 4 + GDScript.

## What this build contains

- 1-survivor start with a sleeping bag, fire pit, 2 Cooked Food and 2 Clean Water.
- Active-time-only simulation clock. One game day is 12 active minutes.
- Explicit Pause/Resume. Minimizing, losing focus, or backgrounding the app saves and pauses the simulation. Returning leaves it paused.
- Autosave to `user://first_fire_alpha01.json`.
- Camp / Craft / Build / Survivors navigation.
- Raw Food / Cooked Food and Dirty Water / Clean Water conversion at the Fire Pit.
- Twelve-resource early-game economy.
- Use-based skill progression: Combat, Scavenging, Survival, Medical, Technical and Social.
- Backgrounds, traits, fatigue, stress, injuries, equipment, relationships and survivor history.
- Five escalating broad expedition zones from 10 to 60 seconds.
- Zone depletion and loot-focus selection.
- Solo or two-survivor expeditions.
- Routine danger resolution and gear discovery.
- Recruitment protection against extremely bad RNG during the 1–5 survivor alpha.
- Expedition special events and named one-use special sites.
- Camp events driven by stress, overcrowding, relationships and repeated expedition duty.
- Coordinator politics at population 3 and a formal election at population 5.
- Rain Catcher, Makeshift Shelter, Storage Crate, Workbench, Sewing Table, Garden Plot, Noise Line and Cabin.
- Multi-station components for the Cabin and Reinforced Pack.
- Alpha completion event once population 5 + core infrastructure + cabin + elected leader are achieved.
- Reserved ad bar placeholder. No real ad SDK or IAP is connected in this development build.

## Run it on Linux first

1. Install a current Godot 4 release.
2. Open Godot Project Manager.
3. Import this folder by selecting `project.godot`.
4. Open the project and press **F6/F5** (Run Project).

The project uses the Compatibility renderer to stay friendly to older Android hardware.

## Android later

Godot's Android export setup requires Android export templates plus a configured Android SDK and Java SDK. Keep developing/testing on Linux first; once the game loop feels right, configure an Android export preset and install a debug APK on the old Android device.

## Important Alpha behavior

This is intentionally *not* an idle game. Timers advance only while the simulation is active. Backgrounding or minimizing pauses and saves immediately, and returning to the app does not automatically resume.

## Monetization architecture

The top ad area is only a visual placeholder right now. The intended release design is one small banner, one cold-launch ad, and a permanent $0.99 Remove Ads purchase. Gameplay systems never consult ad state, and there are no paid timer skips, resources, survivors, revives, power-ups or premium currency.

## Development note

This is the first playable implementation pass. The values live in `scripts/FFData.gd`; simulation logic lives in `scripts/Game.gd`; the intentionally plain phone UI lives in `scripts/Main.gd`.

## Alpha 0.1.2 interface repair

This package includes the first post-playtest repair pass:

- Added startup menu: **New Game / Load Game / Return to Camp / Exit**.
- Added an in-game **MENU** button next to Pause/Resume.
- Camp now has a dedicated Camp Status block showing population, ready food, clean water, shelter, threat, and cohesion.
- Build always lists every Alpha 0.1 structure, including locked/unaffordable structures, with requirements and costs visible.
- Survivor screen now exposes the founder immediately, adds quick survivor buttons, and places a large **SEND OUT** action near the top.
- Save loading now repairs missing resource/building/survivor fields from earlier Alpha saves where possible.
- Existing save path remains `user://first_fire_alpha01.json`.


Alpha 0.1.2 parser fix: nullable survivor/event lookups are explicitly typed as Variant for Godot 4.7.x, preventing null type inference cascades.
