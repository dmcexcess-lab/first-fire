FIRST FIRE — WEB READY BUILD

This is the same Alpha 0.1 UI Fix 3 project with a Godot 4.7 Web export preset added.
No gameplay, balance, timer, art, or UI behavior was changed.

To export locally in Godot 4.7.1:
1. Open the project.
2. If Godot asks for export templates, install them from Editor > Manage Export Templates.
3. Project > Export.
4. Select Web.
5. Export Project. The preset targets web/index.html.

The exported Web build must be served by an HTTP/HTTPS server; browsers generally do not run Godot Web builds correctly from file://.
Browser saves use Godot's user:// storage backed by browser storage/IndexedDB.
